import candidato as cand


for i in range(20):
    acao = input('1-CADASTRAR NOVO CANDIDATO\n2-TODOS OS CANDIDATOS \n3- LiSTA DE VOTOS POR CANDIDATO \n4- LISTA DE CANDIDATO POR REGIAO\n')

    if acao == '2':
         cand.listarCandidatos()
    elif acao == '1':
        cand.cadastrar()
    elif acao == '3':
        cand.listarPorVotos()
    elif acao == '4':
        cand.listarRegiao()
    #elif acao == '5':
     #   cand.votar()
    else:
        print('valor invalido')
