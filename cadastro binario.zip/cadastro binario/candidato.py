import pickle
class Candidato(object):
     def __init__(self,cod_cand,nome, cargo, regiao,votos):
        self.cod_cand = cod_cand
        self.nome = nome
        self.cargo = cargo
        self.regiao = regiao
        self.votos = votos


def cadastrar():
     
     arquivo = open("arquivo.dat", "a")
     for i in range(1):
          nome = input("digite o nome do candidato: ")
          numero = str(input("digite o numero do candidato: "))
          cargo = input("digite o cargo do candidato: ")
          regiao = input("digite a regiao do candidato: ")
          votos = str(input("digite os votos do candidato: "))
          
          arquivo.write(nome +'\n')
          arquivo.write(numero +'\n' )
          arquivo.write(cargo +'\n')
          arquivo.write(regiao +'\n')
          arquivo.write(votos +'\n')
          
          
         # pickle.dump(nome,arq)
          #pickle.dump(numero  ,arq)
          #pickle.dump(cargo,arq)
          #pickle.dump(regiao,arq)
          #pickle.dump(votos,arq)
          print("candidato cadastrado com sucesso")
          print("_______________________________")
     arquivo.close()



def listarCandidatos():
     

     arq = open('arquivo.dat', 'r')
     #s = arq.readline() 
     
     #print("\n")
     count = 0
     c =1
     a = arq.readlines()
     lista = len(a)
     list = int(lista/5)
     #for i in arq:
     print("______________________")
     print("Candidatos:")
     for i in range(list):
          print("Candidato n°",c,": ", a[count])
          c +=1
          count += 5
     arq.close()
          

     
     print('\nLeitura realizada com sucesso!')
     print("_______________________________")

def listarPorVotos():
     count = 0
     totVotos = 0
     arq = open('arquivo.dat', 'r')
     
     
     a = arq.readlines()
     lista = len(a)
     list = int(lista/5)
     #for i in arq:
     print("_______________________________")
     print("Votos por candidato")
     for i in range(list):
          print(a[count].rstrip())
          count += 4
          print(a[count].rstrip())
          print("_______________")
          totVotos = totVotos + int(a[count]) 
          count += 1
     
     print("total de candidatos", lista/5)
     print("total de votos",totVotos )
     print("__________________________" )
     arq.close()

def listarRegiao():
     
     arq = open('arquivo.dat', 'r')
     listaRegiao = []
     count = 3
     a = arq.readlines()
     lista = len(a)
     lista = int(lista) /5
     
     for i in range(int(lista)):
          listaRegiao.append(a[count])
          count += 5
     print("__________________________" )
     print("Candidatos por região" )
     print({x:listaRegiao.count(x) for x in set(listaRegiao)})
     print("__________________________" )
          #print(listaRegiao)

     arq.close()

def votar():
     arq = open('arquivo.dat', 'r')
     
     
     count = 0
     a = arq.readlines()
     lista = len(a)
     list = int(lista/5)
     #for i in arq:
     print("______________________")
     print("Candidatos:")
     for i in range(list):
          print("Candidato", a[count], "n° ",a[count+1])
          #c +=1
          count += 5
    
     
     voto = int(input('informe o numero do candidato: '))
     cnt = 1
     for i in a:
          if int(a[cnt]) == voto:
               cacheVoto = int(a[cnt+ 3])
               cacheVoto +=1
               cacheVoto = str(cacheVoto)
               arq.close()
               votar2(cacheVoto,cnt)

          else:
               print("numero não corresponte a um cabdidato")
               
     
          cnt += 5


    
    
  
     
          
     

     
     
